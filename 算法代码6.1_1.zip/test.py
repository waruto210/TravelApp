# a = [1, 2, 3]
# b = list(a)
#
#
# def test(a: list):
#     a[0] = 5
#
#
# test(b)
# print(a)

# a = [1, 2, 3]
# b = [1, 2, 4]
# c = list(a)
# c[0] = 8
# tmp = []
# tmp.append(a)
# tmp.append(b)
# if c in tmp:
#     print("zai")
# import numpy as np
# a = [1, 2, 4, 0]
# print(np.argsort(a))
import numpy as np
import itertools
import random
import time
# time1 = time.time()
# for i in range(10000):
#     a = np.random.randint(0, 100)
# time2 = time.time()
# print('cost is ', time2-time1)
# time3 = time.time()
# for i in range(10000):
#     a = random.randint(0, 100)
# time4 = time.time()
# print('cost is ', time4-time3)
# t = [dict] * 10
#
# if not t[0]:
#     print("here")
b = [1, 2, 3, 4]
a = list(itertools.permutations([4, 5, 6], 3))
print(a)
random.shuffle(a)
print(a)
